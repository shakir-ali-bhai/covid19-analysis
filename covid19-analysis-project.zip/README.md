# COVID-19 Data Analysis Project

This project analyzes a COVID-19 dataset alongside the World Happiness dataset to explore relationships between pandemic impact and indicators like happiness score, GDP per capita, social support, health, and freedom.

## Files
- `assignment5_covid19_analysis.ipynb` — The main notebook with step-by-step code & explanations.
- `d4f34721-3f69-4e8a-8eec-35aa3cbaf03a.csv` — COVID-19 dataset (as provided).
- `03b510f8-b944-4ec4-bb50-25bd53ebd492.csv` — Happiness dataset (as provided).
- `figures/` — Saved charts (PNG).

## What the Notebook Covers
1. **Load** both datasets.
2. **Inspect** schema and preview.
3. **Clean** and standardize country names.
4. **Engineer** COVID aggregates (latest totals, CFR, peaks).
5. **Prepare** happiness indicators and select relevant columns.
6. **Merge** by `Country`.
7. **Correlate** COVID outcomes with happiness features.
8. **Visualize** top-10 bar charts, scatter plots, and a correlation heatmap.

## How to Run
1. Open the notebook in Jupyter (Lab or Notebook).
2. Run cells top-to-bottom. The code detects column names flexibly across common dataset variants.
3. Figures will be saved to `figures/`.

## Submission Tips
- Zip this folder (`covid19-analysis-project`) and upload to Google Drive or push to a public GitHub repo.
- Include a short write-up of key findings in your course portal submission (you can draw from charts and correlation table).

## Notes
- Correlation is **not** causation. Interpret patterns with care.
- If your dataset schema differs, the `guess_col` helper aims to adapt. If it fails to detect a column, adjust the candidates in the helper.
